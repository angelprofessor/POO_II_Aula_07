﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UNIP.POOII.BS_BlibliotecaPOOII
{
    public abstract class bsNegocio
    {
    }
}
