namespace RibbonDemo
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.ribbon1 = new System.Windows.Forms.Ribbon();
            this.ribbonOrbMenuItem1 = new System.Windows.Forms.RibbonOrbMenuItem();
            this.ribbonOrbMenuItem2 = new System.Windows.Forms.RibbonOrbMenuItem();
            this.ribbonOrbMenuItem3 = new System.Windows.Forms.RibbonOrbMenuItem();
            this.ribbonOrbMenuItem4 = new System.Windows.Forms.RibbonOrbMenuItem();
            this.ribbonSeparator6 = new System.Windows.Forms.RibbonSeparator();
            this.ribbonDescriptionMenuItem1 = new System.Windows.Forms.RibbonDescriptionMenuItem();
            this.ribbonDescriptionMenuItem2 = new System.Windows.Forms.RibbonDescriptionMenuItem();
            this.ribbonDescriptionMenuItem3 = new System.Windows.Forms.RibbonDescriptionMenuItem();
            this.ribbonDescriptionMenuItem4 = new System.Windows.Forms.RibbonDescriptionMenuItem();
            this.ribbonDescriptionMenuItem5 = new System.Windows.Forms.RibbonDescriptionMenuItem();
            this.ribbonSeparator3 = new System.Windows.Forms.RibbonSeparator();
            this.ribbonOrbMenuItem5 = new System.Windows.Forms.RibbonOrbMenuItem();
            this.ribbonSeparator5 = new System.Windows.Forms.RibbonSeparator();
            this.ribbonDescriptionMenuItem6 = new System.Windows.Forms.RibbonDescriptionMenuItem();
            this.ribbonDescriptionMenuItem7 = new System.Windows.Forms.RibbonDescriptionMenuItem();
            this.ribbonDescriptionMenuItem8 = new System.Windows.Forms.RibbonDescriptionMenuItem();
            this.ribbonOrbMenuItem6 = new System.Windows.Forms.RibbonOrbMenuItem();
            this.ribbonOrbMenuItem7 = new System.Windows.Forms.RibbonOrbMenuItem();
            this.ribbonOrbMenuItem8 = new System.Windows.Forms.RibbonOrbMenuItem();
            this.ribbonSeparator4 = new System.Windows.Forms.RibbonSeparator();
            this.ribbonOrbMenuItem9 = new System.Windows.Forms.RibbonOrbMenuItem();
            this.ribbonOrbOptionButton1 = new System.Windows.Forms.RibbonOrbOptionButton();
            this.ribbonOrbOptionButton2 = new System.Windows.Forms.RibbonOrbOptionButton();
            this.ribbonOrbRecentItem1 = new System.Windows.Forms.RibbonOrbRecentItem();
            this.ribbonOrbRecentItem2 = new System.Windows.Forms.RibbonOrbRecentItem();
            this.ribbonOrbRecentItem3 = new System.Windows.Forms.RibbonOrbRecentItem();
            this.ribbonButton42 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton43 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton44 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton45 = new System.Windows.Forms.RibbonButton();
            this.ribbonTab1 = new System.Windows.Forms.RibbonTab();
            this.ribbonPanel1 = new System.Windows.Forms.RibbonPanel();
            this.ribbonButton1 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton2 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton3 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton4 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton5 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton6 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton7 = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel2 = new System.Windows.Forms.RibbonPanel();
            this.ribbonItemGroup1 = new System.Windows.Forms.RibbonItemGroup();
            this.ribbonComboBox1 = new System.Windows.Forms.RibbonComboBox();
            this.ribbonComboBox2 = new System.Windows.Forms.RibbonComboBox();
            this.ribbonItemGroup2 = new System.Windows.Forms.RibbonItemGroup();
            this.ribbonButton8 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton9 = new System.Windows.Forms.RibbonButton();
            this.ribbonItemGroup3 = new System.Windows.Forms.RibbonItemGroup();
            this.ribbonButton10 = new System.Windows.Forms.RibbonButton();
            this.ribbonItemGroup4 = new System.Windows.Forms.RibbonItemGroup();
            this.ribbonButton11 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton12 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton13 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton14 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton15 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton16 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton17 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton18 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton19 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton20 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton21 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton22 = new System.Windows.Forms.RibbonButton();
            this.ribbonItemGroup5 = new System.Windows.Forms.RibbonItemGroup();
            this.ribbonColorChooser1 = new System.Windows.Forms.RibbonColorChooser();
            this.ribbonColorChooser2 = new System.Windows.Forms.RibbonColorChooser();
            this.ribbonPanel3 = new System.Windows.Forms.RibbonPanel();
            this.ribbonItemGroup6 = new System.Windows.Forms.RibbonItemGroup();
            this.ribbonButton23 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton24 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton25 = new System.Windows.Forms.RibbonButton();
            this.ribbonItemGroup7 = new System.Windows.Forms.RibbonItemGroup();
            this.ribbonButton26 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton27 = new System.Windows.Forms.RibbonButton();
            this.ribbonItemGroup8 = new System.Windows.Forms.RibbonItemGroup();
            this.ribbonButton29 = new System.Windows.Forms.RibbonButton();
            this.ribbonItemGroup9 = new System.Windows.Forms.RibbonItemGroup();
            this.ribbonButton28 = new System.Windows.Forms.RibbonButton();
            this.ribbonItemGroup10 = new System.Windows.Forms.RibbonItemGroup();
            this.ribbonColorChooser3 = new System.Windows.Forms.RibbonColorChooser();
            this.ribbonButton31 = new System.Windows.Forms.RibbonButton();
            this.ribbonItemGroup11 = new System.Windows.Forms.RibbonItemGroup();
            this.ribbonButton30 = new System.Windows.Forms.RibbonButton();
            this.ribbonItemGroup12 = new System.Windows.Forms.RibbonItemGroup();
            this.ribbonButton32 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton33 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton34 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton35 = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel4 = new System.Windows.Forms.RibbonPanel();
            this.lst = new System.Windows.Forms.RibbonButtonList();
            this.ribbonButton36 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton37 = new System.Windows.Forms.RibbonButton();
            this.itemColors = new System.Windows.Forms.RibbonButton();
            this.ribbonButton38 = new System.Windows.Forms.RibbonButton();
            this.ribbonSeparator2 = new System.Windows.Forms.RibbonSeparator();
            this.ribbonButton41 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton39 = new System.Windows.Forms.RibbonButton();
            this.ribbonSeparator1 = new System.Windows.Forms.RibbonSeparator();
            this.ribbonButton40 = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel5 = new System.Windows.Forms.RibbonPanel();
            this.ribbonButton46 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton47 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton48 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton49 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton50 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton51 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton52 = new System.Windows.Forms.RibbonButton();
            this.SuspendLayout();
            // 
            // ribbon1
            // 
            this.ribbon1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ribbon1.Location = new System.Drawing.Point(0, 0);
            this.ribbon1.Minimized = false;
            this.ribbon1.Name = "ribbon1";
            // 
            // 
            // 
            this.ribbon1.OrbDropDown.BorderRoundness = 8;
            this.ribbon1.OrbDropDown.Location = new System.Drawing.Point(0, 0);
            this.ribbon1.OrbDropDown.MenuItems.Add(this.ribbonOrbMenuItem1);
            this.ribbon1.OrbDropDown.MenuItems.Add(this.ribbonOrbMenuItem2);
            this.ribbon1.OrbDropDown.MenuItems.Add(this.ribbonOrbMenuItem3);
            this.ribbon1.OrbDropDown.MenuItems.Add(this.ribbonOrbMenuItem4);
            this.ribbon1.OrbDropDown.MenuItems.Add(this.ribbonSeparator3);
            this.ribbon1.OrbDropDown.MenuItems.Add(this.ribbonOrbMenuItem5);
            this.ribbon1.OrbDropDown.MenuItems.Add(this.ribbonOrbMenuItem6);
            this.ribbon1.OrbDropDown.MenuItems.Add(this.ribbonOrbMenuItem7);
            this.ribbon1.OrbDropDown.MenuItems.Add(this.ribbonOrbMenuItem8);
            this.ribbon1.OrbDropDown.MenuItems.Add(this.ribbonSeparator4);
            this.ribbon1.OrbDropDown.MenuItems.Add(this.ribbonOrbMenuItem9);
            this.ribbon1.OrbDropDown.Name = "";
            this.ribbon1.OrbDropDown.OptionItems.Add(this.ribbonOrbOptionButton1);
            this.ribbon1.OrbDropDown.OptionItems.Add(this.ribbonOrbOptionButton2);
            this.ribbon1.OrbDropDown.RecentItems.Add(this.ribbonOrbRecentItem1);
            this.ribbon1.OrbDropDown.RecentItems.Add(this.ribbonOrbRecentItem2);
            this.ribbon1.OrbDropDown.RecentItems.Add(this.ribbonOrbRecentItem3);
            this.ribbon1.OrbDropDown.Size = new System.Drawing.Size(527, 474);
            this.ribbon1.OrbDropDown.TabIndex = 0;
            this.ribbon1.OrbImage = null;
            // 
            // 
            // 
            this.ribbon1.QuickAcessToolbar.AltKey = null;
            this.ribbon1.QuickAcessToolbar.Image = null;
            this.ribbon1.QuickAcessToolbar.Items.Add(this.ribbonButton42);
            this.ribbon1.QuickAcessToolbar.Items.Add(this.ribbonButton43);
            this.ribbon1.QuickAcessToolbar.Items.Add(this.ribbonButton44);
            this.ribbon1.QuickAcessToolbar.Items.Add(this.ribbonButton45);
            this.ribbon1.QuickAcessToolbar.Tag = null;
            this.ribbon1.QuickAcessToolbar.Text = null;
            this.ribbon1.QuickAcessToolbar.ToolTip = null;
            this.ribbon1.QuickAcessToolbar.ToolTipImage = null;
            this.ribbon1.QuickAcessToolbar.ToolTipTitle = null;
            this.ribbon1.Size = new System.Drawing.Size(931, 138);
            this.ribbon1.TabIndex = 0;
            this.ribbon1.Tabs.Add(this.ribbonTab1);
            this.ribbon1.TabSpacing = 6;
            this.ribbon1.Text = "ribbon1";
            // 
            // ribbonOrbMenuItem1
            // 
            this.ribbonOrbMenuItem1.AltKey = null;
            this.ribbonOrbMenuItem1.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonOrbMenuItem1.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonOrbMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem1.Image")));
            this.ribbonOrbMenuItem1.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem1.SmallImage")));
            this.ribbonOrbMenuItem1.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonOrbMenuItem1.Tag = null;
            this.ribbonOrbMenuItem1.Text = "New";
            this.ribbonOrbMenuItem1.ToolTip = null;
            this.ribbonOrbMenuItem1.ToolTipImage = null;
            this.ribbonOrbMenuItem1.ToolTipTitle = null;
            // 
            // ribbonOrbMenuItem2
            // 
            this.ribbonOrbMenuItem2.AltKey = null;
            this.ribbonOrbMenuItem2.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonOrbMenuItem2.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonOrbMenuItem2.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem2.Image")));
            this.ribbonOrbMenuItem2.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem2.SmallImage")));
            this.ribbonOrbMenuItem2.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonOrbMenuItem2.Tag = null;
            this.ribbonOrbMenuItem2.Text = "Open";
            this.ribbonOrbMenuItem2.ToolTip = null;
            this.ribbonOrbMenuItem2.ToolTipImage = null;
            this.ribbonOrbMenuItem2.ToolTipTitle = null;
            // 
            // ribbonOrbMenuItem3
            // 
            this.ribbonOrbMenuItem3.AltKey = null;
            this.ribbonOrbMenuItem3.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonOrbMenuItem3.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonOrbMenuItem3.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem3.Image")));
            this.ribbonOrbMenuItem3.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem3.SmallImage")));
            this.ribbonOrbMenuItem3.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonOrbMenuItem3.Tag = null;
            this.ribbonOrbMenuItem3.Text = "Save";
            this.ribbonOrbMenuItem3.ToolTip = null;
            this.ribbonOrbMenuItem3.ToolTipImage = null;
            this.ribbonOrbMenuItem3.ToolTipTitle = null;
            // 
            // ribbonOrbMenuItem4
            // 
            this.ribbonOrbMenuItem4.AltKey = null;
            this.ribbonOrbMenuItem4.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonOrbMenuItem4.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonOrbMenuItem4.DropDownItems.Add(this.ribbonSeparator6);
            this.ribbonOrbMenuItem4.DropDownItems.Add(this.ribbonDescriptionMenuItem1);
            this.ribbonOrbMenuItem4.DropDownItems.Add(this.ribbonDescriptionMenuItem2);
            this.ribbonOrbMenuItem4.DropDownItems.Add(this.ribbonDescriptionMenuItem3);
            this.ribbonOrbMenuItem4.DropDownItems.Add(this.ribbonDescriptionMenuItem4);
            this.ribbonOrbMenuItem4.DropDownItems.Add(this.ribbonDescriptionMenuItem5);
            this.ribbonOrbMenuItem4.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem4.Image")));
            this.ribbonOrbMenuItem4.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem4.SmallImage")));
            this.ribbonOrbMenuItem4.Style = System.Windows.Forms.RibbonButtonStyle.SplitDropDown;
            this.ribbonOrbMenuItem4.Tag = null;
            this.ribbonOrbMenuItem4.Text = "Save as";
            this.ribbonOrbMenuItem4.ToolTip = null;
            this.ribbonOrbMenuItem4.ToolTipImage = null;
            this.ribbonOrbMenuItem4.ToolTipTitle = null;
            // 
            // ribbonSeparator6
            // 
            this.ribbonSeparator6.AltKey = null;
            this.ribbonSeparator6.Image = null;
            this.ribbonSeparator6.Tag = null;
            this.ribbonSeparator6.Text = "Save a copy of the document";
            this.ribbonSeparator6.ToolTip = null;
            this.ribbonSeparator6.ToolTipImage = null;
            this.ribbonSeparator6.ToolTipTitle = null;
            // 
            // ribbonDescriptionMenuItem1
            // 
            this.ribbonDescriptionMenuItem1.AltKey = null;
            this.ribbonDescriptionMenuItem1.Description = "Save the document in the default file format";
            this.ribbonDescriptionMenuItem1.DescriptionBounds = new System.Drawing.Rectangle(46, 24, 315, 28);
            this.ribbonDescriptionMenuItem1.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonDescriptionMenuItem1.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonDescriptionMenuItem1.Image = global::RibbonDemo.Properties.Resources.worddocument32;
            this.ribbonDescriptionMenuItem1.SmallImage = global::RibbonDemo.Properties.Resources.worddocument32;
            this.ribbonDescriptionMenuItem1.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonDescriptionMenuItem1.Tag = null;
            this.ribbonDescriptionMenuItem1.Text = "Word Document";
            this.ribbonDescriptionMenuItem1.ToolTip = null;
            this.ribbonDescriptionMenuItem1.ToolTipImage = null;
            this.ribbonDescriptionMenuItem1.ToolTipTitle = null;
            // 
            // ribbonDescriptionMenuItem2
            // 
            this.ribbonDescriptionMenuItem2.AltKey = null;
            this.ribbonDescriptionMenuItem2.Description = "Save the document as a template that can be used to format future documents";
            this.ribbonDescriptionMenuItem2.DescriptionBounds = new System.Drawing.Rectangle(46, 76, 315, 28);
            this.ribbonDescriptionMenuItem2.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonDescriptionMenuItem2.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonDescriptionMenuItem2.Image = global::RibbonDemo.Properties.Resources.wordtemplate32;
            this.ribbonDescriptionMenuItem2.SmallImage = global::RibbonDemo.Properties.Resources.wordtemplate32;
            this.ribbonDescriptionMenuItem2.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonDescriptionMenuItem2.Tag = null;
            this.ribbonDescriptionMenuItem2.Text = "Word Template";
            this.ribbonDescriptionMenuItem2.ToolTip = null;
            this.ribbonDescriptionMenuItem2.ToolTipImage = null;
            this.ribbonDescriptionMenuItem2.ToolTipTitle = null;
            // 
            // ribbonDescriptionMenuItem3
            // 
            this.ribbonDescriptionMenuItem3.AltKey = null;
            this.ribbonDescriptionMenuItem3.Description = "Save a copy of the document that is fully compatible with  Word 93 - 2007";
            this.ribbonDescriptionMenuItem3.DescriptionBounds = new System.Drawing.Rectangle(46, 128, 315, 28);
            this.ribbonDescriptionMenuItem3.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonDescriptionMenuItem3.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonDescriptionMenuItem3.Image = global::RibbonDemo.Properties.Resources.word2003doc32;
            this.ribbonDescriptionMenuItem3.SmallImage = global::RibbonDemo.Properties.Resources.word2003doc32;
            this.ribbonDescriptionMenuItem3.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonDescriptionMenuItem3.Tag = null;
            this.ribbonDescriptionMenuItem3.Text = "Word 97 - 2003";
            this.ribbonDescriptionMenuItem3.ToolTip = null;
            this.ribbonDescriptionMenuItem3.ToolTipImage = null;
            this.ribbonDescriptionMenuItem3.ToolTipTitle = null;
            // 
            // ribbonDescriptionMenuItem4
            // 
            this.ribbonDescriptionMenuItem4.AltKey = null;
            this.ribbonDescriptionMenuItem4.Description = "Learn about add-ins to save to other formats like XPS or PDF";
            this.ribbonDescriptionMenuItem4.DescriptionBounds = new System.Drawing.Rectangle(46, 180, 315, 28);
            this.ribbonDescriptionMenuItem4.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonDescriptionMenuItem4.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonDescriptionMenuItem4.Image = global::RibbonDemo.Properties.Resources.addons32;
            this.ribbonDescriptionMenuItem4.SmallImage = global::RibbonDemo.Properties.Resources.addons32;
            this.ribbonDescriptionMenuItem4.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonDescriptionMenuItem4.Tag = null;
            this.ribbonDescriptionMenuItem4.Text = "Find add-ins for other file formats";
            this.ribbonDescriptionMenuItem4.ToolTip = null;
            this.ribbonDescriptionMenuItem4.ToolTipImage = null;
            this.ribbonDescriptionMenuItem4.ToolTipTitle = null;
            // 
            // ribbonDescriptionMenuItem5
            // 
            this.ribbonDescriptionMenuItem5.AltKey = null;
            this.ribbonDescriptionMenuItem5.Description = "Open the save as dialog to choose between the all available formats to save.";
            this.ribbonDescriptionMenuItem5.DescriptionBounds = new System.Drawing.Rectangle(46, 232, 315, 28);
            this.ribbonDescriptionMenuItem5.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonDescriptionMenuItem5.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonDescriptionMenuItem5.Image = global::RibbonDemo.Properties.Resources.saveas321;
            this.ribbonDescriptionMenuItem5.SmallImage = global::RibbonDemo.Properties.Resources.saveas321;
            this.ribbonDescriptionMenuItem5.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonDescriptionMenuItem5.Tag = null;
            this.ribbonDescriptionMenuItem5.Text = "Other Formats";
            this.ribbonDescriptionMenuItem5.ToolTip = null;
            this.ribbonDescriptionMenuItem5.ToolTipImage = null;
            this.ribbonDescriptionMenuItem5.ToolTipTitle = null;
            // 
            // ribbonSeparator3
            // 
            this.ribbonSeparator3.AltKey = null;
            this.ribbonSeparator3.Image = null;
            this.ribbonSeparator3.Tag = null;
            this.ribbonSeparator3.Text = null;
            this.ribbonSeparator3.ToolTip = null;
            this.ribbonSeparator3.ToolTipImage = null;
            this.ribbonSeparator3.ToolTipTitle = null;
            // 
            // ribbonOrbMenuItem5
            // 
            this.ribbonOrbMenuItem5.AltKey = null;
            this.ribbonOrbMenuItem5.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonOrbMenuItem5.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonOrbMenuItem5.DropDownItems.Add(this.ribbonSeparator5);
            this.ribbonOrbMenuItem5.DropDownItems.Add(this.ribbonDescriptionMenuItem6);
            this.ribbonOrbMenuItem5.DropDownItems.Add(this.ribbonDescriptionMenuItem7);
            this.ribbonOrbMenuItem5.DropDownItems.Add(this.ribbonDescriptionMenuItem8);
            this.ribbonOrbMenuItem5.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem5.Image")));
            this.ribbonOrbMenuItem5.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem5.SmallImage")));
            this.ribbonOrbMenuItem5.Style = System.Windows.Forms.RibbonButtonStyle.SplitDropDown;
            this.ribbonOrbMenuItem5.Tag = null;
            this.ribbonOrbMenuItem5.Text = "Print";
            this.ribbonOrbMenuItem5.ToolTip = null;
            this.ribbonOrbMenuItem5.ToolTipImage = null;
            this.ribbonOrbMenuItem5.ToolTipTitle = null;
            // 
            // ribbonSeparator5
            // 
            this.ribbonSeparator5.AltKey = null;
            this.ribbonSeparator5.Image = null;
            this.ribbonSeparator5.Tag = null;
            this.ribbonSeparator5.Text = "Preview and print the document";
            this.ribbonSeparator5.ToolTip = null;
            this.ribbonSeparator5.ToolTipImage = null;
            this.ribbonSeparator5.ToolTipTitle = null;
            // 
            // ribbonDescriptionMenuItem6
            // 
            this.ribbonDescriptionMenuItem6.AltKey = null;
            this.ribbonDescriptionMenuItem6.Description = "Select a printer, number of copies and other options before printing";
            this.ribbonDescriptionMenuItem6.DescriptionBounds = new System.Drawing.Rectangle(46, 45, 315, 28);
            this.ribbonDescriptionMenuItem6.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonDescriptionMenuItem6.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonDescriptionMenuItem6.Image = global::RibbonDemo.Properties.Resources.print321;
            this.ribbonDescriptionMenuItem6.SmallImage = global::RibbonDemo.Properties.Resources.print321;
            this.ribbonDescriptionMenuItem6.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonDescriptionMenuItem6.Tag = null;
            this.ribbonDescriptionMenuItem6.Text = "Print";
            this.ribbonDescriptionMenuItem6.ToolTip = null;
            this.ribbonDescriptionMenuItem6.ToolTipImage = null;
            this.ribbonDescriptionMenuItem6.ToolTipTitle = null;
            // 
            // ribbonDescriptionMenuItem7
            // 
            this.ribbonDescriptionMenuItem7.AltKey = null;
            this.ribbonDescriptionMenuItem7.Description = "Send the document directly to the printer without making changes";
            this.ribbonDescriptionMenuItem7.DescriptionBounds = new System.Drawing.Rectangle(46, 97, 315, 28);
            this.ribbonDescriptionMenuItem7.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonDescriptionMenuItem7.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonDescriptionMenuItem7.Image = global::RibbonDemo.Properties.Resources.printquick32;
            this.ribbonDescriptionMenuItem7.SmallImage = global::RibbonDemo.Properties.Resources.printquick32;
            this.ribbonDescriptionMenuItem7.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonDescriptionMenuItem7.Tag = null;
            this.ribbonDescriptionMenuItem7.Text = "Quick Print";
            this.ribbonDescriptionMenuItem7.ToolTip = null;
            this.ribbonDescriptionMenuItem7.ToolTipImage = null;
            this.ribbonDescriptionMenuItem7.ToolTipTitle = null;
            // 
            // ribbonDescriptionMenuItem8
            // 
            this.ribbonDescriptionMenuItem8.AltKey = null;
            this.ribbonDescriptionMenuItem8.Description = "Preview and make changes to pages before printing.";
            this.ribbonDescriptionMenuItem8.DescriptionBounds = new System.Drawing.Rectangle(46, 149, 315, 28);
            this.ribbonDescriptionMenuItem8.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonDescriptionMenuItem8.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonDescriptionMenuItem8.Image = global::RibbonDemo.Properties.Resources.printpreview32;
            this.ribbonDescriptionMenuItem8.SmallImage = global::RibbonDemo.Properties.Resources.printpreview32;
            this.ribbonDescriptionMenuItem8.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonDescriptionMenuItem8.Tag = null;
            this.ribbonDescriptionMenuItem8.Text = "Print Preview";
            this.ribbonDescriptionMenuItem8.ToolTip = null;
            this.ribbonDescriptionMenuItem8.ToolTipImage = null;
            this.ribbonDescriptionMenuItem8.ToolTipTitle = null;
            // 
            // ribbonOrbMenuItem6
            // 
            this.ribbonOrbMenuItem6.AltKey = null;
            this.ribbonOrbMenuItem6.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonOrbMenuItem6.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonOrbMenuItem6.Image = global::RibbonDemo.Properties.Resources.prepare32;
            this.ribbonOrbMenuItem6.SmallImage = global::RibbonDemo.Properties.Resources.prepare32;
            this.ribbonOrbMenuItem6.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonOrbMenuItem6.Tag = null;
            this.ribbonOrbMenuItem6.Text = "Prepare";
            this.ribbonOrbMenuItem6.ToolTip = null;
            this.ribbonOrbMenuItem6.ToolTipImage = null;
            this.ribbonOrbMenuItem6.ToolTipTitle = null;
            // 
            // ribbonOrbMenuItem7
            // 
            this.ribbonOrbMenuItem7.AltKey = null;
            this.ribbonOrbMenuItem7.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonOrbMenuItem7.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonOrbMenuItem7.Image = global::RibbonDemo.Properties.Resources.send32;
            this.ribbonOrbMenuItem7.SmallImage = global::RibbonDemo.Properties.Resources.send32;
            this.ribbonOrbMenuItem7.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonOrbMenuItem7.Tag = null;
            this.ribbonOrbMenuItem7.Text = "Send";
            this.ribbonOrbMenuItem7.ToolTip = null;
            this.ribbonOrbMenuItem7.ToolTipImage = null;
            this.ribbonOrbMenuItem7.ToolTipTitle = null;
            // 
            // ribbonOrbMenuItem8
            // 
            this.ribbonOrbMenuItem8.AltKey = null;
            this.ribbonOrbMenuItem8.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonOrbMenuItem8.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonOrbMenuItem8.Image = global::RibbonDemo.Properties.Resources.publish32;
            this.ribbonOrbMenuItem8.SmallImage = global::RibbonDemo.Properties.Resources.publish32;
            this.ribbonOrbMenuItem8.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonOrbMenuItem8.Tag = null;
            this.ribbonOrbMenuItem8.Text = "Publish";
            this.ribbonOrbMenuItem8.ToolTip = null;
            this.ribbonOrbMenuItem8.ToolTipImage = null;
            this.ribbonOrbMenuItem8.ToolTipTitle = null;
            // 
            // ribbonSeparator4
            // 
            this.ribbonSeparator4.AltKey = null;
            this.ribbonSeparator4.Image = null;
            this.ribbonSeparator4.Tag = null;
            this.ribbonSeparator4.Text = null;
            this.ribbonSeparator4.ToolTip = null;
            this.ribbonSeparator4.ToolTipImage = null;
            this.ribbonSeparator4.ToolTipTitle = null;
            // 
            // ribbonOrbMenuItem9
            // 
            this.ribbonOrbMenuItem9.AltKey = null;
            this.ribbonOrbMenuItem9.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonOrbMenuItem9.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonOrbMenuItem9.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem9.Image")));
            this.ribbonOrbMenuItem9.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem9.SmallImage")));
            this.ribbonOrbMenuItem9.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonOrbMenuItem9.Tag = null;
            this.ribbonOrbMenuItem9.Text = "Close";
            this.ribbonOrbMenuItem9.ToolTip = null;
            this.ribbonOrbMenuItem9.ToolTipImage = null;
            this.ribbonOrbMenuItem9.ToolTipTitle = null;
            // 
            // ribbonOrbOptionButton1
            // 
            this.ribbonOrbOptionButton1.AltKey = null;
            this.ribbonOrbOptionButton1.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonOrbOptionButton1.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonOrbOptionButton1.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbOptionButton1.Image")));
            this.ribbonOrbOptionButton1.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbOptionButton1.SmallImage")));
            this.ribbonOrbOptionButton1.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonOrbOptionButton1.Tag = null;
            this.ribbonOrbOptionButton1.Text = "Exit Ribbon Demo";
            this.ribbonOrbOptionButton1.ToolTip = null;
            this.ribbonOrbOptionButton1.ToolTipImage = null;
            this.ribbonOrbOptionButton1.ToolTipTitle = null;
            this.ribbonOrbOptionButton1.Click += new System.EventHandler(this.ribbonOrbOptionButton1_Click);
            // 
            // ribbonOrbOptionButton2
            // 
            this.ribbonOrbOptionButton2.AltKey = null;
            this.ribbonOrbOptionButton2.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonOrbOptionButton2.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonOrbOptionButton2.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbOptionButton2.Image")));
            this.ribbonOrbOptionButton2.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbOptionButton2.SmallImage")));
            this.ribbonOrbOptionButton2.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonOrbOptionButton2.Tag = null;
            this.ribbonOrbOptionButton2.Text = "Ribbon Demo Options";
            this.ribbonOrbOptionButton2.ToolTip = null;
            this.ribbonOrbOptionButton2.ToolTipImage = null;
            this.ribbonOrbOptionButton2.ToolTipTitle = null;
            // 
            // ribbonOrbRecentItem1
            // 
            this.ribbonOrbRecentItem1.AltKey = null;
            this.ribbonOrbRecentItem1.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonOrbRecentItem1.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonOrbRecentItem1.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbRecentItem1.Image")));
            this.ribbonOrbRecentItem1.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbRecentItem1.SmallImage")));
            this.ribbonOrbRecentItem1.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonOrbRecentItem1.Tag = null;
            this.ribbonOrbRecentItem1.Text = "Recent Document 1";
            this.ribbonOrbRecentItem1.ToolTip = null;
            this.ribbonOrbRecentItem1.ToolTipImage = null;
            this.ribbonOrbRecentItem1.ToolTipTitle = null;
            // 
            // ribbonOrbRecentItem2
            // 
            this.ribbonOrbRecentItem2.AltKey = null;
            this.ribbonOrbRecentItem2.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonOrbRecentItem2.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonOrbRecentItem2.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbRecentItem2.Image")));
            this.ribbonOrbRecentItem2.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbRecentItem2.SmallImage")));
            this.ribbonOrbRecentItem2.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonOrbRecentItem2.Tag = null;
            this.ribbonOrbRecentItem2.Text = "Recent Document 2";
            this.ribbonOrbRecentItem2.ToolTip = null;
            this.ribbonOrbRecentItem2.ToolTipImage = null;
            this.ribbonOrbRecentItem2.ToolTipTitle = null;
            // 
            // ribbonOrbRecentItem3
            // 
            this.ribbonOrbRecentItem3.AltKey = null;
            this.ribbonOrbRecentItem3.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonOrbRecentItem3.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonOrbRecentItem3.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbRecentItem3.Image")));
            this.ribbonOrbRecentItem3.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbRecentItem3.SmallImage")));
            this.ribbonOrbRecentItem3.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonOrbRecentItem3.Tag = null;
            this.ribbonOrbRecentItem3.Text = "Recent Document 3";
            this.ribbonOrbRecentItem3.ToolTip = null;
            this.ribbonOrbRecentItem3.ToolTipImage = null;
            this.ribbonOrbRecentItem3.ToolTipTitle = null;
            // 
            // ribbonButton42
            // 
            this.ribbonButton42.AltKey = null;
            this.ribbonButton42.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton42.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton42.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton42.Image")));
            this.ribbonButton42.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton42.SmallImage = global::RibbonDemo.Properties.Resources.save16;
            this.ribbonButton42.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton42.Tag = null;
            this.ribbonButton42.Text = "ribbonButton42";
            this.ribbonButton42.ToolTip = null;
            this.ribbonButton42.ToolTipImage = null;
            this.ribbonButton42.ToolTipTitle = null;
            // 
            // ribbonButton43
            // 
            this.ribbonButton43.AltKey = null;
            this.ribbonButton43.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton43.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton43.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton43.Image")));
            this.ribbonButton43.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton43.SmallImage = global::RibbonDemo.Properties.Resources.printquick16;
            this.ribbonButton43.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton43.Tag = null;
            this.ribbonButton43.Text = "ribbonButton43";
            this.ribbonButton43.ToolTip = null;
            this.ribbonButton43.ToolTipImage = null;
            this.ribbonButton43.ToolTipTitle = null;
            // 
            // ribbonButton44
            // 
            this.ribbonButton44.AltKey = null;
            this.ribbonButton44.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton44.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton44.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton44.Image")));
            this.ribbonButton44.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton44.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton44.SmallImage")));
            this.ribbonButton44.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton44.Tag = null;
            this.ribbonButton44.Text = "ribbonButton44";
            this.ribbonButton44.ToolTip = null;
            this.ribbonButton44.ToolTipImage = null;
            this.ribbonButton44.ToolTipTitle = null;
            // 
            // ribbonButton45
            // 
            this.ribbonButton45.AltKey = null;
            this.ribbonButton45.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton45.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton45.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton45.Image")));
            this.ribbonButton45.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton45.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton45.SmallImage")));
            this.ribbonButton45.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton45.Tag = null;
            this.ribbonButton45.Text = "ribbonButton45";
            this.ribbonButton45.ToolTip = null;
            this.ribbonButton45.ToolTipImage = null;
            this.ribbonButton45.ToolTipTitle = null;
            // 
            // ribbonTab1
            // 
            this.ribbonTab1.Panels.Add(this.ribbonPanel1);
            this.ribbonTab1.Panels.Add(this.ribbonPanel2);
            this.ribbonTab1.Panels.Add(this.ribbonPanel3);
            this.ribbonTab1.Panels.Add(this.ribbonPanel4);
            this.ribbonTab1.Panels.Add(this.ribbonPanel5);
            this.ribbonTab1.Tag = null;
            this.ribbonTab1.Text = "Start";
            // 
            // ribbonPanel1
            // 
            this.ribbonPanel1.Image = ((System.Drawing.Image)(resources.GetObject("ribbonPanel1.Image")));
            this.ribbonPanel1.Items.Add(this.ribbonButton1);
            this.ribbonPanel1.Items.Add(this.ribbonButton5);
            this.ribbonPanel1.Items.Add(this.ribbonButton6);
            this.ribbonPanel1.Items.Add(this.ribbonButton7);
            this.ribbonPanel1.Tag = null;
            this.ribbonPanel1.Text = "Clipboard";
            // 
            // ribbonButton1
            // 
            this.ribbonButton1.AltKey = null;
            this.ribbonButton1.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton1.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton1.DropDownItems.Add(this.ribbonButton2);
            this.ribbonButton1.DropDownItems.Add(this.ribbonButton3);
            this.ribbonButton1.DropDownItems.Add(this.ribbonButton4);
            this.ribbonButton1.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton1.Image")));
            this.ribbonButton1.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Large;
            this.ribbonButton1.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton1.SmallImage")));
            this.ribbonButton1.Style = System.Windows.Forms.RibbonButtonStyle.SplitDropDown;
            this.ribbonButton1.Tag = null;
            this.ribbonButton1.Text = "Paste";
            this.ribbonButton1.ToolTip = null;
            this.ribbonButton1.ToolTipImage = null;
            this.ribbonButton1.ToolTipTitle = null;
            // 
            // ribbonButton2
            // 
            this.ribbonButton2.AltKey = null;
            this.ribbonButton2.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonButton2.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton2.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton2.Image")));
            this.ribbonButton2.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton2.SmallImage")));
            this.ribbonButton2.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton2.Tag = null;
            this.ribbonButton2.Text = "Paste";
            this.ribbonButton2.ToolTip = null;
            this.ribbonButton2.ToolTipImage = null;
            this.ribbonButton2.ToolTipTitle = null;
            // 
            // ribbonButton3
            // 
            this.ribbonButton3.AltKey = null;
            this.ribbonButton3.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonButton3.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton3.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton3.Image")));
            this.ribbonButton3.SmallImage = global::RibbonDemo.Properties.Resources.pastespecial16;
            this.ribbonButton3.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton3.Tag = null;
            this.ribbonButton3.Text = "Paste special...";
            this.ribbonButton3.ToolTip = null;
            this.ribbonButton3.ToolTipImage = null;
            this.ribbonButton3.ToolTipTitle = null;
            // 
            // ribbonButton4
            // 
            this.ribbonButton4.AltKey = null;
            this.ribbonButton4.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonButton4.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton4.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton4.Image")));
            this.ribbonButton4.SmallImage = global::RibbonDemo.Properties.Resources.pastelink16;
            this.ribbonButton4.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton4.Tag = null;
            this.ribbonButton4.Text = "Paste as link";
            this.ribbonButton4.ToolTip = null;
            this.ribbonButton4.ToolTipImage = null;
            this.ribbonButton4.ToolTipTitle = null;
            // 
            // ribbonButton5
            // 
            this.ribbonButton5.AltKey = null;
            this.ribbonButton5.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton5.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton5.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton5.Image")));
            this.ribbonButton5.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium;
            this.ribbonButton5.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton5.SmallImage")));
            this.ribbonButton5.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton5.Tag = null;
            this.ribbonButton5.Text = "Cut";
            this.ribbonButton5.ToolTip = null;
            this.ribbonButton5.ToolTipImage = null;
            this.ribbonButton5.ToolTipTitle = null;
            // 
            // ribbonButton6
            // 
            this.ribbonButton6.AltKey = null;
            this.ribbonButton6.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton6.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton6.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton6.Image")));
            this.ribbonButton6.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium;
            this.ribbonButton6.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton6.SmallImage")));
            this.ribbonButton6.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton6.Tag = null;
            this.ribbonButton6.Text = "Copy";
            this.ribbonButton6.ToolTip = null;
            this.ribbonButton6.ToolTipImage = null;
            this.ribbonButton6.ToolTipTitle = null;
            // 
            // ribbonButton7
            // 
            this.ribbonButton7.AltKey = null;
            this.ribbonButton7.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton7.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton7.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton7.Image")));
            this.ribbonButton7.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium;
            this.ribbonButton7.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton7.SmallImage")));
            this.ribbonButton7.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton7.Tag = null;
            this.ribbonButton7.Text = "Paste";
            this.ribbonButton7.ToolTip = null;
            this.ribbonButton7.ToolTipImage = null;
            this.ribbonButton7.ToolTipTitle = null;
            // 
            // ribbonPanel2
            // 
            this.ribbonPanel2.FlowsTo = System.Windows.Forms.RibbonPanelFlowDirection.Right;
            this.ribbonPanel2.Image = ((System.Drawing.Image)(resources.GetObject("ribbonPanel2.Image")));
            this.ribbonPanel2.Items.Add(this.ribbonItemGroup1);
            this.ribbonPanel2.Items.Add(this.ribbonItemGroup2);
            this.ribbonPanel2.Items.Add(this.ribbonItemGroup3);
            this.ribbonPanel2.Items.Add(this.ribbonItemGroup4);
            this.ribbonPanel2.Items.Add(this.ribbonItemGroup5);
            this.ribbonPanel2.Tag = null;
            this.ribbonPanel2.Text = "Font";
            // 
            // ribbonItemGroup1
            // 
            this.ribbonItemGroup1.AltKey = null;
            this.ribbonItemGroup1.DrawBackground = false;
            this.ribbonItemGroup1.Image = null;
            this.ribbonItemGroup1.Items.Add(this.ribbonComboBox1);
            this.ribbonItemGroup1.Items.Add(this.ribbonComboBox2);
            this.ribbonItemGroup1.Tag = null;
            this.ribbonItemGroup1.Text = "ribbonItemGroup1";
            this.ribbonItemGroup1.ToolTip = null;
            this.ribbonItemGroup1.ToolTipImage = null;
            this.ribbonItemGroup1.ToolTipTitle = null;
            // 
            // ribbonComboBox1
            // 
            this.ribbonComboBox1.AltKey = null;
            this.ribbonComboBox1.Image = null;
            this.ribbonComboBox1.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonComboBox1.Tag = null;
            this.ribbonComboBox1.Text = "ribbonComboBox1";
            this.ribbonComboBox1.TextBoxText = "Calibri";
            this.ribbonComboBox1.TextBoxWidth = 160;
            this.ribbonComboBox1.ToolTip = null;
            this.ribbonComboBox1.ToolTipImage = null;
            this.ribbonComboBox1.ToolTipTitle = null;
            // 
            // ribbonComboBox2
            // 
            this.ribbonComboBox2.AltKey = null;
            this.ribbonComboBox2.Image = null;
            this.ribbonComboBox2.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonComboBox2.Tag = null;
            this.ribbonComboBox2.Text = "ribbonComboBox2";
            this.ribbonComboBox2.TextBoxText = "11";
            this.ribbonComboBox2.TextBoxWidth = 40;
            this.ribbonComboBox2.ToolTip = null;
            this.ribbonComboBox2.ToolTipImage = null;
            this.ribbonComboBox2.ToolTipTitle = null;
            // 
            // ribbonItemGroup2
            // 
            this.ribbonItemGroup2.AltKey = null;
            this.ribbonItemGroup2.Image = null;
            this.ribbonItemGroup2.Items.Add(this.ribbonButton8);
            this.ribbonItemGroup2.Items.Add(this.ribbonButton9);
            this.ribbonItemGroup2.Tag = null;
            this.ribbonItemGroup2.Text = "ribbonItemGroup2";
            this.ribbonItemGroup2.ToolTip = null;
            this.ribbonItemGroup2.ToolTipImage = null;
            this.ribbonItemGroup2.ToolTipTitle = null;
            // 
            // ribbonButton8
            // 
            this.ribbonButton8.AltKey = null;
            this.ribbonButton8.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton8.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton8.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton8.Image")));
            this.ribbonButton8.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton8.SmallImage = global::RibbonDemo.Properties.Resources.fontsizeincrease16;
            this.ribbonButton8.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton8.Tag = null;
            this.ribbonButton8.Text = "ribbonButton8";
            this.ribbonButton8.ToolTip = null;
            this.ribbonButton8.ToolTipImage = null;
            this.ribbonButton8.ToolTipTitle = null;
            // 
            // ribbonButton9
            // 
            this.ribbonButton9.AltKey = null;
            this.ribbonButton9.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton9.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton9.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton9.Image")));
            this.ribbonButton9.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton9.SmallImage = global::RibbonDemo.Properties.Resources.fontsizedecrease16;
            this.ribbonButton9.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton9.Tag = null;
            this.ribbonButton9.Text = "ribbonButton9";
            this.ribbonButton9.ToolTip = null;
            this.ribbonButton9.ToolTipImage = null;
            this.ribbonButton9.ToolTipTitle = null;
            // 
            // ribbonItemGroup3
            // 
            this.ribbonItemGroup3.AltKey = null;
            this.ribbonItemGroup3.Image = null;
            this.ribbonItemGroup3.Items.Add(this.ribbonButton10);
            this.ribbonItemGroup3.Tag = null;
            this.ribbonItemGroup3.Text = "ribbonItemGroup3";
            this.ribbonItemGroup3.ToolTip = null;
            this.ribbonItemGroup3.ToolTipImage = null;
            this.ribbonItemGroup3.ToolTipTitle = null;
            // 
            // ribbonButton10
            // 
            this.ribbonButton10.AltKey = null;
            this.ribbonButton10.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton10.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton10.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton10.Image")));
            this.ribbonButton10.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton10.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton10.SmallImage")));
            this.ribbonButton10.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton10.Tag = null;
            this.ribbonButton10.Text = "ribbonButton10";
            this.ribbonButton10.ToolTip = null;
            this.ribbonButton10.ToolTipImage = null;
            this.ribbonButton10.ToolTipTitle = null;
            // 
            // ribbonItemGroup4
            // 
            this.ribbonItemGroup4.AltKey = null;
            this.ribbonItemGroup4.Image = null;
            this.ribbonItemGroup4.Items.Add(this.ribbonButton11);
            this.ribbonItemGroup4.Items.Add(this.ribbonButton12);
            this.ribbonItemGroup4.Items.Add(this.ribbonButton13);
            this.ribbonItemGroup4.Items.Add(this.ribbonButton14);
            this.ribbonItemGroup4.Items.Add(this.ribbonButton15);
            this.ribbonItemGroup4.Items.Add(this.ribbonButton16);
            this.ribbonItemGroup4.Items.Add(this.ribbonButton17);
            this.ribbonItemGroup4.Tag = null;
            this.ribbonItemGroup4.Text = "ribbonItemGroup4";
            this.ribbonItemGroup4.ToolTip = null;
            this.ribbonItemGroup4.ToolTipImage = null;
            this.ribbonItemGroup4.ToolTipTitle = null;
            // 
            // ribbonButton11
            // 
            this.ribbonButton11.AltKey = null;
            this.ribbonButton11.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton11.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton11.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton11.Image")));
            this.ribbonButton11.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton11.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton11.SmallImage")));
            this.ribbonButton11.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton11.Tag = null;
            this.ribbonButton11.Text = "ribbonButton11";
            this.ribbonButton11.ToolTip = null;
            this.ribbonButton11.ToolTipImage = null;
            this.ribbonButton11.ToolTipTitle = null;
            // 
            // ribbonButton12
            // 
            this.ribbonButton12.AltKey = null;
            this.ribbonButton12.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton12.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton12.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton12.Image")));
            this.ribbonButton12.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton12.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton12.SmallImage")));
            this.ribbonButton12.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton12.Tag = null;
            this.ribbonButton12.Text = "ribbonButton12";
            this.ribbonButton12.ToolTip = null;
            this.ribbonButton12.ToolTipImage = null;
            this.ribbonButton12.ToolTipTitle = null;
            // 
            // ribbonButton13
            // 
            this.ribbonButton13.AltKey = null;
            this.ribbonButton13.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton13.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton13.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton13.Image")));
            this.ribbonButton13.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton13.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton13.SmallImage")));
            this.ribbonButton13.Style = System.Windows.Forms.RibbonButtonStyle.SplitDropDown;
            this.ribbonButton13.Tag = null;
            this.ribbonButton13.Text = "ribbonButton13";
            this.ribbonButton13.ToolTip = null;
            this.ribbonButton13.ToolTipImage = null;
            this.ribbonButton13.ToolTipTitle = null;
            // 
            // ribbonButton14
            // 
            this.ribbonButton14.AltKey = null;
            this.ribbonButton14.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton14.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton14.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton14.Image")));
            this.ribbonButton14.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton14.SmallImage = global::RibbonDemo.Properties.Resources.strikethru16;
            this.ribbonButton14.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton14.Tag = null;
            this.ribbonButton14.Text = "ribbonButton14";
            this.ribbonButton14.ToolTip = null;
            this.ribbonButton14.ToolTipImage = null;
            this.ribbonButton14.ToolTipTitle = null;
            // 
            // ribbonButton15
            // 
            this.ribbonButton15.AltKey = null;
            this.ribbonButton15.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton15.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton15.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton15.Image")));
            this.ribbonButton15.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton15.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton15.SmallImage")));
            this.ribbonButton15.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton15.Tag = null;
            this.ribbonButton15.Text = "ribbonButton15";
            this.ribbonButton15.ToolTip = null;
            this.ribbonButton15.ToolTipImage = null;
            this.ribbonButton15.ToolTipTitle = null;
            // 
            // ribbonButton16
            // 
            this.ribbonButton16.AltKey = null;
            this.ribbonButton16.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton16.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton16.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton16.Image")));
            this.ribbonButton16.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton16.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton16.SmallImage")));
            this.ribbonButton16.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton16.Tag = null;
            this.ribbonButton16.Text = "ribbonButton16";
            this.ribbonButton16.ToolTip = null;
            this.ribbonButton16.ToolTipImage = null;
            this.ribbonButton16.ToolTipTitle = null;
            // 
            // ribbonButton17
            // 
            this.ribbonButton17.AltKey = null;
            this.ribbonButton17.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton17.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton17.DropDownItems.Add(this.ribbonButton18);
            this.ribbonButton17.DropDownItems.Add(this.ribbonButton19);
            this.ribbonButton17.DropDownItems.Add(this.ribbonButton20);
            this.ribbonButton17.DropDownItems.Add(this.ribbonButton21);
            this.ribbonButton17.DropDownItems.Add(this.ribbonButton22);
            this.ribbonButton17.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton17.Image")));
            this.ribbonButton17.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton17.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton17.SmallImage")));
            this.ribbonButton17.Style = System.Windows.Forms.RibbonButtonStyle.DropDown;
            this.ribbonButton17.Tag = null;
            this.ribbonButton17.Text = "ribbonButton17";
            this.ribbonButton17.ToolTip = null;
            this.ribbonButton17.ToolTipImage = null;
            this.ribbonButton17.ToolTipTitle = null;
            // 
            // ribbonButton18
            // 
            this.ribbonButton18.AltKey = null;
            this.ribbonButton18.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonButton18.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton18.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton18.Image")));
            this.ribbonButton18.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton18.SmallImage")));
            this.ribbonButton18.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton18.Tag = null;
            this.ribbonButton18.Text = "Sentence case.";
            this.ribbonButton18.ToolTip = null;
            this.ribbonButton18.ToolTipImage = null;
            this.ribbonButton18.ToolTipTitle = null;
            // 
            // ribbonButton19
            // 
            this.ribbonButton19.AltKey = null;
            this.ribbonButton19.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonButton19.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton19.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton19.Image")));
            this.ribbonButton19.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton19.SmallImage")));
            this.ribbonButton19.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton19.Tag = null;
            this.ribbonButton19.Text = "lowercase";
            this.ribbonButton19.ToolTip = null;
            this.ribbonButton19.ToolTipImage = null;
            this.ribbonButton19.ToolTipTitle = null;
            // 
            // ribbonButton20
            // 
            this.ribbonButton20.AltKey = null;
            this.ribbonButton20.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonButton20.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton20.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton20.Image")));
            this.ribbonButton20.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton20.SmallImage")));
            this.ribbonButton20.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton20.Tag = null;
            this.ribbonButton20.Text = "UPPERCASE";
            this.ribbonButton20.ToolTip = null;
            this.ribbonButton20.ToolTipImage = null;
            this.ribbonButton20.ToolTipTitle = null;
            // 
            // ribbonButton21
            // 
            this.ribbonButton21.AltKey = null;
            this.ribbonButton21.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonButton21.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton21.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton21.Image")));
            this.ribbonButton21.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton21.SmallImage")));
            this.ribbonButton21.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton21.Tag = null;
            this.ribbonButton21.Text = "Capitalize Each Word";
            this.ribbonButton21.ToolTip = null;
            this.ribbonButton21.ToolTipImage = null;
            this.ribbonButton21.ToolTipTitle = null;
            // 
            // ribbonButton22
            // 
            this.ribbonButton22.AltKey = null;
            this.ribbonButton22.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonButton22.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton22.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton22.Image")));
            this.ribbonButton22.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton22.SmallImage")));
            this.ribbonButton22.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton22.Tag = null;
            this.ribbonButton22.Text = "tOGGLE cASE";
            this.ribbonButton22.ToolTip = null;
            this.ribbonButton22.ToolTipImage = null;
            this.ribbonButton22.ToolTipTitle = null;
            // 
            // ribbonItemGroup5
            // 
            this.ribbonItemGroup5.AltKey = null;
            this.ribbonItemGroup5.Image = null;
            this.ribbonItemGroup5.Items.Add(this.ribbonColorChooser1);
            this.ribbonItemGroup5.Items.Add(this.ribbonColorChooser2);
            this.ribbonItemGroup5.Tag = null;
            this.ribbonItemGroup5.Text = "ribbonItemGroup5";
            this.ribbonItemGroup5.ToolTip = null;
            this.ribbonItemGroup5.ToolTipImage = null;
            this.ribbonItemGroup5.ToolTipTitle = null;
            // 
            // ribbonColorChooser1
            // 
            this.ribbonColorChooser1.AltKey = null;
            this.ribbonColorChooser1.Color = System.Drawing.Color.Yellow;
            this.ribbonColorChooser1.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonColorChooser1.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonColorChooser1.Image = ((System.Drawing.Image)(resources.GetObject("ribbonColorChooser1.Image")));
            this.ribbonColorChooser1.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonColorChooser1.SmallImage = global::RibbonDemo.Properties.Resources.hilight16;
            this.ribbonColorChooser1.Style = System.Windows.Forms.RibbonButtonStyle.SplitDropDown;
            this.ribbonColorChooser1.Tag = null;
            this.ribbonColorChooser1.Text = "ribbonColorChooser1";
            this.ribbonColorChooser1.ToolTip = null;
            this.ribbonColorChooser1.ToolTipImage = null;
            this.ribbonColorChooser1.ToolTipTitle = null;
            // 
            // ribbonColorChooser2
            // 
            this.ribbonColorChooser2.AltKey = null;
            this.ribbonColorChooser2.Color = System.Drawing.Color.Blue;
            this.ribbonColorChooser2.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonColorChooser2.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonColorChooser2.Image = null;
            this.ribbonColorChooser2.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonColorChooser2.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonColorChooser2.SmallImage")));
            this.ribbonColorChooser2.Style = System.Windows.Forms.RibbonButtonStyle.SplitDropDown;
            this.ribbonColorChooser2.Tag = null;
            this.ribbonColorChooser2.Text = "ribbonColorChooser2";
            this.ribbonColorChooser2.ToolTip = null;
            this.ribbonColorChooser2.ToolTipImage = null;
            this.ribbonColorChooser2.ToolTipTitle = null;
            // 
            // ribbonPanel3
            // 
            this.ribbonPanel3.FlowsTo = System.Windows.Forms.RibbonPanelFlowDirection.Right;
            this.ribbonPanel3.Image = global::RibbonDemo.Properties.Resources.textaligncenter16;
            this.ribbonPanel3.Items.Add(this.ribbonItemGroup6);
            this.ribbonPanel3.Items.Add(this.ribbonItemGroup7);
            this.ribbonPanel3.Items.Add(this.ribbonItemGroup8);
            this.ribbonPanel3.Items.Add(this.ribbonItemGroup9);
            this.ribbonPanel3.Items.Add(this.ribbonItemGroup10);
            this.ribbonPanel3.Items.Add(this.ribbonItemGroup11);
            this.ribbonPanel3.Items.Add(this.ribbonItemGroup12);
            this.ribbonPanel3.Tag = null;
            this.ribbonPanel3.Text = "Paragraph";
            // 
            // ribbonItemGroup6
            // 
            this.ribbonItemGroup6.AltKey = null;
            this.ribbonItemGroup6.Image = null;
            this.ribbonItemGroup6.Items.Add(this.ribbonButton23);
            this.ribbonItemGroup6.Items.Add(this.ribbonButton24);
            this.ribbonItemGroup6.Items.Add(this.ribbonButton25);
            this.ribbonItemGroup6.Tag = null;
            this.ribbonItemGroup6.Text = "ribbonItemGroup6";
            this.ribbonItemGroup6.ToolTip = null;
            this.ribbonItemGroup6.ToolTipImage = null;
            this.ribbonItemGroup6.ToolTipTitle = null;
            // 
            // ribbonButton23
            // 
            this.ribbonButton23.AltKey = null;
            this.ribbonButton23.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton23.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton23.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton23.Image")));
            this.ribbonButton23.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton23.SmallImage = global::RibbonDemo.Properties.Resources.unorderedlist16;
            this.ribbonButton23.Style = System.Windows.Forms.RibbonButtonStyle.SplitDropDown;
            this.ribbonButton23.Tag = null;
            this.ribbonButton23.Text = "ribbonButton23";
            this.ribbonButton23.ToolTip = null;
            this.ribbonButton23.ToolTipImage = null;
            this.ribbonButton23.ToolTipTitle = null;
            // 
            // ribbonButton24
            // 
            this.ribbonButton24.AltKey = null;
            this.ribbonButton24.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton24.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton24.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton24.Image")));
            this.ribbonButton24.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton24.SmallImage = global::RibbonDemo.Properties.Resources.orderedlist16;
            this.ribbonButton24.Style = System.Windows.Forms.RibbonButtonStyle.SplitDropDown;
            this.ribbonButton24.Tag = null;
            this.ribbonButton24.Text = "ribbonButton24";
            this.ribbonButton24.ToolTip = null;
            this.ribbonButton24.ToolTipImage = null;
            this.ribbonButton24.ToolTipTitle = null;
            // 
            // ribbonButton25
            // 
            this.ribbonButton25.AltKey = null;
            this.ribbonButton25.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton25.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton25.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton25.Image")));
            this.ribbonButton25.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton25.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton25.SmallImage")));
            this.ribbonButton25.Style = System.Windows.Forms.RibbonButtonStyle.DropDown;
            this.ribbonButton25.Tag = null;
            this.ribbonButton25.Text = "ribbonButton25";
            this.ribbonButton25.ToolTip = null;
            this.ribbonButton25.ToolTipImage = null;
            this.ribbonButton25.ToolTipTitle = null;
            // 
            // ribbonItemGroup7
            // 
            this.ribbonItemGroup7.AltKey = null;
            this.ribbonItemGroup7.Image = null;
            this.ribbonItemGroup7.Items.Add(this.ribbonButton26);
            this.ribbonItemGroup7.Items.Add(this.ribbonButton27);
            this.ribbonItemGroup7.Tag = null;
            this.ribbonItemGroup7.Text = "ribbonItemGroup7";
            this.ribbonItemGroup7.ToolTip = null;
            this.ribbonItemGroup7.ToolTipImage = null;
            this.ribbonItemGroup7.ToolTipTitle = null;
            // 
            // ribbonButton26
            // 
            this.ribbonButton26.AltKey = null;
            this.ribbonButton26.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton26.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton26.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton26.Image")));
            this.ribbonButton26.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton26.SmallImage = global::RibbonDemo.Properties.Resources.indentdecrease16;
            this.ribbonButton26.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton26.Tag = null;
            this.ribbonButton26.Text = "ribbonButton26";
            this.ribbonButton26.ToolTip = null;
            this.ribbonButton26.ToolTipImage = null;
            this.ribbonButton26.ToolTipTitle = null;
            // 
            // ribbonButton27
            // 
            this.ribbonButton27.AltKey = null;
            this.ribbonButton27.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton27.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton27.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton27.Image")));
            this.ribbonButton27.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton27.SmallImage = global::RibbonDemo.Properties.Resources.indentincrease16;
            this.ribbonButton27.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton27.Tag = null;
            this.ribbonButton27.Text = "ribbonButton27";
            this.ribbonButton27.ToolTip = null;
            this.ribbonButton27.ToolTipImage = null;
            this.ribbonButton27.ToolTipTitle = null;
            // 
            // ribbonItemGroup8
            // 
            this.ribbonItemGroup8.AltKey = null;
            this.ribbonItemGroup8.Image = null;
            this.ribbonItemGroup8.Items.Add(this.ribbonButton29);
            this.ribbonItemGroup8.Tag = null;
            this.ribbonItemGroup8.Text = "ribbonItemGroup8";
            this.ribbonItemGroup8.ToolTip = null;
            this.ribbonItemGroup8.ToolTipImage = null;
            this.ribbonItemGroup8.ToolTipTitle = null;
            // 
            // ribbonButton29
            // 
            this.ribbonButton29.AltKey = null;
            this.ribbonButton29.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton29.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton29.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton29.Image")));
            this.ribbonButton29.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton29.SmallImage = global::RibbonDemo.Properties.Resources.invisiblechars16;
            this.ribbonButton29.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton29.Tag = null;
            this.ribbonButton29.Text = "ribbonButton29";
            this.ribbonButton29.ToolTip = null;
            this.ribbonButton29.ToolTipImage = null;
            this.ribbonButton29.ToolTipTitle = null;
            // 
            // ribbonItemGroup9
            // 
            this.ribbonItemGroup9.AltKey = null;
            this.ribbonItemGroup9.Image = null;
            this.ribbonItemGroup9.Items.Add(this.ribbonButton28);
            this.ribbonItemGroup9.Tag = null;
            this.ribbonItemGroup9.Text = "ribbonItemGroup9";
            this.ribbonItemGroup9.ToolTip = null;
            this.ribbonItemGroup9.ToolTipImage = null;
            this.ribbonItemGroup9.ToolTipTitle = null;
            // 
            // ribbonButton28
            // 
            this.ribbonButton28.AltKey = null;
            this.ribbonButton28.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton28.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton28.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton28.Image")));
            this.ribbonButton28.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton28.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton28.SmallImage")));
            this.ribbonButton28.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton28.Tag = null;
            this.ribbonButton28.Text = "ribbonButton28";
            this.ribbonButton28.ToolTip = null;
            this.ribbonButton28.ToolTipImage = null;
            this.ribbonButton28.ToolTipTitle = null;
            // 
            // ribbonItemGroup10
            // 
            this.ribbonItemGroup10.AltKey = null;
            this.ribbonItemGroup10.Image = null;
            this.ribbonItemGroup10.Items.Add(this.ribbonColorChooser3);
            this.ribbonItemGroup10.Items.Add(this.ribbonButton31);
            this.ribbonItemGroup10.Tag = null;
            this.ribbonItemGroup10.Text = "ribbonItemGroup10";
            this.ribbonItemGroup10.ToolTip = null;
            this.ribbonItemGroup10.ToolTipImage = null;
            this.ribbonItemGroup10.ToolTipTitle = null;
            // 
            // ribbonColorChooser3
            // 
            this.ribbonColorChooser3.AltKey = null;
            this.ribbonColorChooser3.Color = System.Drawing.Color.Transparent;
            this.ribbonColorChooser3.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonColorChooser3.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonColorChooser3.Image = ((System.Drawing.Image)(resources.GetObject("ribbonColorChooser3.Image")));
            this.ribbonColorChooser3.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonColorChooser3.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonColorChooser3.SmallImage")));
            this.ribbonColorChooser3.Style = System.Windows.Forms.RibbonButtonStyle.SplitDropDown;
            this.ribbonColorChooser3.Tag = null;
            this.ribbonColorChooser3.Text = "ribbonColorChooser3";
            this.ribbonColorChooser3.ToolTip = null;
            this.ribbonColorChooser3.ToolTipImage = null;
            this.ribbonColorChooser3.ToolTipTitle = null;
            // 
            // ribbonButton31
            // 
            this.ribbonButton31.AltKey = null;
            this.ribbonButton31.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton31.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton31.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton31.Image")));
            this.ribbonButton31.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton31.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton31.SmallImage")));
            this.ribbonButton31.Style = System.Windows.Forms.RibbonButtonStyle.SplitDropDown;
            this.ribbonButton31.Tag = null;
            this.ribbonButton31.Text = "ribbonButton31";
            this.ribbonButton31.ToolTip = null;
            this.ribbonButton31.ToolTipImage = null;
            this.ribbonButton31.ToolTipTitle = null;
            // 
            // ribbonItemGroup11
            // 
            this.ribbonItemGroup11.AltKey = null;
            this.ribbonItemGroup11.Image = null;
            this.ribbonItemGroup11.Items.Add(this.ribbonButton30);
            this.ribbonItemGroup11.Tag = null;
            this.ribbonItemGroup11.Text = "ribbonItemGroup11";
            this.ribbonItemGroup11.ToolTip = null;
            this.ribbonItemGroup11.ToolTipImage = null;
            this.ribbonItemGroup11.ToolTipTitle = null;
            // 
            // ribbonButton30
            // 
            this.ribbonButton30.AltKey = null;
            this.ribbonButton30.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton30.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton30.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton30.Image")));
            this.ribbonButton30.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton30.SmallImage = global::RibbonDemo.Properties.Resources.paragraphspacing16;
            this.ribbonButton30.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton30.Tag = null;
            this.ribbonButton30.Text = "ribbonButton30";
            this.ribbonButton30.ToolTip = null;
            this.ribbonButton30.ToolTipImage = null;
            this.ribbonButton30.ToolTipTitle = null;
            // 
            // ribbonItemGroup12
            // 
            this.ribbonItemGroup12.AltKey = null;
            this.ribbonItemGroup12.Image = null;
            this.ribbonItemGroup12.Items.Add(this.ribbonButton32);
            this.ribbonItemGroup12.Items.Add(this.ribbonButton33);
            this.ribbonItemGroup12.Items.Add(this.ribbonButton34);
            this.ribbonItemGroup12.Items.Add(this.ribbonButton35);
            this.ribbonItemGroup12.Tag = null;
            this.ribbonItemGroup12.Text = "ribbonItemGroup12";
            this.ribbonItemGroup12.ToolTip = null;
            this.ribbonItemGroup12.ToolTipImage = null;
            this.ribbonItemGroup12.ToolTipTitle = null;
            // 
            // ribbonButton32
            // 
            this.ribbonButton32.AltKey = null;
            this.ribbonButton32.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton32.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton32.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton32.Image")));
            this.ribbonButton32.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton32.SmallImage = global::RibbonDemo.Properties.Resources.textalignleft16;
            this.ribbonButton32.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton32.Tag = null;
            this.ribbonButton32.Text = "ribbonButton32";
            this.ribbonButton32.ToolTip = null;
            this.ribbonButton32.ToolTipImage = null;
            this.ribbonButton32.ToolTipTitle = null;
            // 
            // ribbonButton33
            // 
            this.ribbonButton33.AltKey = null;
            this.ribbonButton33.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton33.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton33.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton33.Image")));
            this.ribbonButton33.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton33.SmallImage = global::RibbonDemo.Properties.Resources.textaligncenter16;
            this.ribbonButton33.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton33.Tag = null;
            this.ribbonButton33.Text = "ribbonButton33";
            this.ribbonButton33.ToolTip = null;
            this.ribbonButton33.ToolTipImage = null;
            this.ribbonButton33.ToolTipTitle = null;
            // 
            // ribbonButton34
            // 
            this.ribbonButton34.AltKey = null;
            this.ribbonButton34.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton34.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton34.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton34.Image")));
            this.ribbonButton34.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton34.SmallImage = global::RibbonDemo.Properties.Resources.textalignright16;
            this.ribbonButton34.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton34.Tag = null;
            this.ribbonButton34.Text = "ribbonButton34";
            this.ribbonButton34.ToolTip = null;
            this.ribbonButton34.ToolTipImage = null;
            this.ribbonButton34.ToolTipTitle = null;
            // 
            // ribbonButton35
            // 
            this.ribbonButton35.AltKey = null;
            this.ribbonButton35.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton35.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton35.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton35.Image")));
            this.ribbonButton35.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton35.SmallImage = global::RibbonDemo.Properties.Resources.textalignjustify16;
            this.ribbonButton35.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton35.Tag = null;
            this.ribbonButton35.Text = "ribbonButton35";
            this.ribbonButton35.ToolTip = null;
            this.ribbonButton35.ToolTipImage = null;
            this.ribbonButton35.ToolTipTitle = null;
            // 
            // ribbonPanel4
            // 
            this.ribbonPanel4.Image = ((System.Drawing.Image)(resources.GetObject("ribbonPanel4.Image")));
            this.ribbonPanel4.Items.Add(this.lst);
            this.ribbonPanel4.Items.Add(this.ribbonButton36);
            this.ribbonPanel4.Tag = null;
            this.ribbonPanel4.Text = "Styles";
            // 
            // lst
            // 
            this.lst.AltKey = null;
            this.lst.ButtonsSizeMode = System.Windows.Forms.RibbonElementSizeMode.Large;
            this.lst.FlowToBottom = false;
            this.lst.Image = null;
            this.lst.ItemsSizeInDropwDownMode = new System.Drawing.Size(7, 5);
            this.lst.Tag = null;
            this.lst.Text = "ribbonButtonList1";
            this.lst.ToolTip = null;
            this.lst.ToolTipImage = null;
            this.lst.ToolTipTitle = null;
            // 
            // ribbonButton36
            // 
            this.ribbonButton36.AltKey = null;
            this.ribbonButton36.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton36.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton36.DropDownItems.Add(this.ribbonButton37);
            this.ribbonButton36.DropDownItems.Add(this.itemColors);
            this.ribbonButton36.DropDownItems.Add(this.ribbonButton39);
            this.ribbonButton36.DropDownItems.Add(this.ribbonSeparator1);
            this.ribbonButton36.DropDownItems.Add(this.ribbonButton40);
            this.ribbonButton36.Image = global::RibbonDemo.Properties.Resources.stylechange32;
            this.ribbonButton36.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Large;
            this.ribbonButton36.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton36.SmallImage")));
            this.ribbonButton36.Style = System.Windows.Forms.RibbonButtonStyle.DropDown;
            this.ribbonButton36.Tag = null;
            this.ribbonButton36.Text = "Change Styles";
            this.ribbonButton36.ToolTip = null;
            this.ribbonButton36.ToolTipImage = null;
            this.ribbonButton36.ToolTipTitle = null;
            // 
            // ribbonButton37
            // 
            this.ribbonButton37.AltKey = null;
            this.ribbonButton37.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonButton37.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton37.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton37.Image")));
            this.ribbonButton37.SmallImage = global::RibbonDemo.Properties.Resources.styleset16;
            this.ribbonButton37.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton37.Tag = null;
            this.ribbonButton37.Text = "Style set";
            this.ribbonButton37.ToolTip = null;
            this.ribbonButton37.ToolTipImage = null;
            this.ribbonButton37.ToolTipTitle = null;
            // 
            // itemColors
            // 
            this.itemColors.AltKey = null;
            this.itemColors.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.itemColors.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.itemColors.DropDownItems.Add(this.ribbonButton38);
            this.itemColors.DropDownItems.Add(this.ribbonSeparator2);
            this.itemColors.DropDownItems.Add(this.ribbonButton41);
            this.itemColors.Image = ((System.Drawing.Image)(resources.GetObject("itemColors.Image")));
            this.itemColors.SmallImage = ((System.Drawing.Image)(resources.GetObject("itemColors.SmallImage")));
            this.itemColors.Style = System.Windows.Forms.RibbonButtonStyle.DropDown;
            this.itemColors.Tag = null;
            this.itemColors.Text = "Colors";
            this.itemColors.ToolTip = null;
            this.itemColors.ToolTipImage = null;
            this.itemColors.ToolTipTitle = null;
            // 
            // ribbonButton38
            // 
            this.ribbonButton38.AltKey = null;
            this.ribbonButton38.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonButton38.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton38.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton38.Image")));
            this.ribbonButton38.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton38.SmallImage")));
            this.ribbonButton38.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton38.Tag = null;
            this.ribbonButton38.Text = "Create new theme colors...";
            this.ribbonButton38.ToolTip = null;
            this.ribbonButton38.ToolTipImage = null;
            this.ribbonButton38.ToolTipTitle = null;
            // 
            // ribbonSeparator2
            // 
            this.ribbonSeparator2.AltKey = null;
            this.ribbonSeparator2.Image = null;
            this.ribbonSeparator2.Tag = null;
            this.ribbonSeparator2.Text = null;
            this.ribbonSeparator2.ToolTip = null;
            this.ribbonSeparator2.ToolTipImage = null;
            this.ribbonSeparator2.ToolTipTitle = null;
            // 
            // ribbonButton41
            // 
            this.ribbonButton41.AltKey = null;
            this.ribbonButton41.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonButton41.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton41.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton41.Image")));
            this.ribbonButton41.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton41.SmallImage")));
            this.ribbonButton41.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton41.Tag = null;
            this.ribbonButton41.Text = "Some other option";
            this.ribbonButton41.ToolTip = null;
            this.ribbonButton41.ToolTipImage = null;
            this.ribbonButton41.ToolTipTitle = null;
            // 
            // ribbonButton39
            // 
            this.ribbonButton39.AltKey = null;
            this.ribbonButton39.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonButton39.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton39.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton39.Image")));
            this.ribbonButton39.SmallImage = global::RibbonDemo.Properties.Resources.themefont;
            this.ribbonButton39.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton39.Tag = null;
            this.ribbonButton39.Text = "Fonts";
            this.ribbonButton39.ToolTip = null;
            this.ribbonButton39.ToolTipImage = null;
            this.ribbonButton39.ToolTipTitle = null;
            // 
            // ribbonSeparator1
            // 
            this.ribbonSeparator1.AltKey = null;
            this.ribbonSeparator1.Image = null;
            this.ribbonSeparator1.Tag = null;
            this.ribbonSeparator1.Text = null;
            this.ribbonSeparator1.ToolTip = null;
            this.ribbonSeparator1.ToolTipImage = null;
            this.ribbonSeparator1.ToolTipTitle = null;
            // 
            // ribbonButton40
            // 
            this.ribbonButton40.AltKey = null;
            this.ribbonButton40.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonButton40.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton40.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton40.Image")));
            this.ribbonButton40.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton40.SmallImage")));
            this.ribbonButton40.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton40.Tag = null;
            this.ribbonButton40.Text = "Set as default value";
            this.ribbonButton40.ToolTip = null;
            this.ribbonButton40.ToolTipImage = null;
            this.ribbonButton40.ToolTipTitle = null;
            // 
            // ribbonPanel5
            // 
            this.ribbonPanel5.Items.Add(this.ribbonButton46);
            this.ribbonPanel5.Items.Add(this.ribbonButton47);
            this.ribbonPanel5.Items.Add(this.ribbonButton48);
            this.ribbonPanel5.Items.Add(this.ribbonButton49);
            this.ribbonPanel5.Tag = null;
            this.ribbonPanel5.Text = "Editing";
            // 
            // ribbonButton46
            // 
            this.ribbonButton46.AltKey = null;
            this.ribbonButton46.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton46.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton46.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton46.Image")));
            this.ribbonButton46.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Large;
            this.ribbonButton46.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton46.SmallImage")));
            this.ribbonButton46.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton46.Tag = null;
            this.ribbonButton46.Text = "Find";
            this.ribbonButton46.ToolTip = null;
            this.ribbonButton46.ToolTipImage = null;
            this.ribbonButton46.ToolTipTitle = null;
            // 
            // ribbonButton47
            // 
            this.ribbonButton47.AltKey = null;
            this.ribbonButton47.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton47.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton47.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton47.Image")));
            this.ribbonButton47.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium;
            this.ribbonButton47.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton47.SmallImage")));
            this.ribbonButton47.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton47.Tag = null;
            this.ribbonButton47.Text = "Replace";
            this.ribbonButton47.ToolTip = null;
            this.ribbonButton47.ToolTipImage = null;
            this.ribbonButton47.ToolTipTitle = null;
            // 
            // ribbonButton48
            // 
            this.ribbonButton48.AltKey = null;
            this.ribbonButton48.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton48.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton48.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton48.Image")));
            this.ribbonButton48.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium;
            this.ribbonButton48.SmallImage = global::RibbonDemo.Properties.Resources.goto16;
            this.ribbonButton48.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton48.Tag = null;
            this.ribbonButton48.Text = "Go To";
            this.ribbonButton48.ToolTip = null;
            this.ribbonButton48.ToolTipImage = null;
            this.ribbonButton48.ToolTipTitle = null;
            // 
            // ribbonButton49
            // 
            this.ribbonButton49.AltKey = null;
            this.ribbonButton49.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Down;
            this.ribbonButton49.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton49.DropDownItems.Add(this.ribbonButton50);
            this.ribbonButton49.DropDownItems.Add(this.ribbonButton51);
            this.ribbonButton49.DropDownItems.Add(this.ribbonButton52);
            this.ribbonButton49.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton49.Image")));
            this.ribbonButton49.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium;
            this.ribbonButton49.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton49.SmallImage")));
            this.ribbonButton49.Style = System.Windows.Forms.RibbonButtonStyle.DropDown;
            this.ribbonButton49.Tag = null;
            this.ribbonButton49.Text = "Select";
            this.ribbonButton49.ToolTip = null;
            this.ribbonButton49.ToolTipImage = null;
            this.ribbonButton49.ToolTipTitle = null;
            // 
            // ribbonButton50
            // 
            this.ribbonButton50.AltKey = null;
            this.ribbonButton50.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonButton50.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton50.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton50.Image")));
            this.ribbonButton50.SmallImage = global::RibbonDemo.Properties.Resources.pageblank16;
            this.ribbonButton50.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton50.Tag = null;
            this.ribbonButton50.Text = "Select everything";
            this.ribbonButton50.ToolTip = null;
            this.ribbonButton50.ToolTipImage = null;
            this.ribbonButton50.ToolTipTitle = null;
            // 
            // ribbonButton51
            // 
            this.ribbonButton51.AltKey = null;
            this.ribbonButton51.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonButton51.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton51.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton51.Image")));
            this.ribbonButton51.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton51.SmallImage")));
            this.ribbonButton51.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton51.Tag = null;
            this.ribbonButton51.Text = "Select Text";
            this.ribbonButton51.ToolTip = null;
            this.ribbonButton51.ToolTipImage = null;
            this.ribbonButton51.ToolTipTitle = null;
            // 
            // ribbonButton52
            // 
            this.ribbonButton52.AltKey = null;
            this.ribbonButton52.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonButton52.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton52.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton52.Image")));
            this.ribbonButton52.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton52.SmallImage")));
            this.ribbonButton52.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton52.Tag = null;
            this.ribbonButton52.Text = "Select text with similar format";
            this.ribbonButton52.ToolTip = null;
            this.ribbonButton52.ToolTipImage = null;
            this.ribbonButton52.ToolTipTitle = null;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(931, 264);
            this.Controls.Add(this.ribbon1);
            this.Name = "MainForm";
            this.Text = "Ribbon Demo Form";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RibbonTab ribbonTab1;
        private System.Windows.Forms.RibbonPanel ribbonPanel1;
        private System.Windows.Forms.RibbonButton ribbonButton1;
        protected System.Windows.Forms.Ribbon ribbon1;
        private System.Windows.Forms.RibbonButton ribbonButton2;
        private System.Windows.Forms.RibbonButton ribbonButton3;
        private System.Windows.Forms.RibbonButton ribbonButton4;
        private System.Windows.Forms.RibbonButton ribbonButton5;
        private System.Windows.Forms.RibbonButton ribbonButton6;
        private System.Windows.Forms.RibbonButton ribbonButton7;
        private System.Windows.Forms.RibbonPanel ribbonPanel2;
        private System.Windows.Forms.RibbonItemGroup ribbonItemGroup1;
        private System.Windows.Forms.RibbonComboBox ribbonComboBox1;
        private System.Windows.Forms.RibbonComboBox ribbonComboBox2;
        private System.Windows.Forms.RibbonItemGroup ribbonItemGroup2;
        private System.Windows.Forms.RibbonButton ribbonButton8;
        private System.Windows.Forms.RibbonButton ribbonButton9;
        private System.Windows.Forms.RibbonItemGroup ribbonItemGroup3;
        private System.Windows.Forms.RibbonButton ribbonButton10;
        private System.Windows.Forms.RibbonItemGroup ribbonItemGroup4;
        private System.Windows.Forms.RibbonButton ribbonButton11;
        private System.Windows.Forms.RibbonButton ribbonButton12;
        private System.Windows.Forms.RibbonButton ribbonButton13;
        private System.Windows.Forms.RibbonButton ribbonButton14;
        private System.Windows.Forms.RibbonButton ribbonButton15;
        private System.Windows.Forms.RibbonButton ribbonButton16;
        private System.Windows.Forms.RibbonButton ribbonButton17;
        private System.Windows.Forms.RibbonButton ribbonButton18;
        private System.Windows.Forms.RibbonButton ribbonButton19;
        private System.Windows.Forms.RibbonButton ribbonButton20;
        private System.Windows.Forms.RibbonButton ribbonButton21;
        private System.Windows.Forms.RibbonButton ribbonButton22;
        private System.Windows.Forms.RibbonPanel ribbonPanel3;
        private System.Windows.Forms.RibbonItemGroup ribbonItemGroup5;
        private System.Windows.Forms.RibbonColorChooser ribbonColorChooser1;
        private System.Windows.Forms.RibbonColorChooser ribbonColorChooser2;
        private System.Windows.Forms.RibbonItemGroup ribbonItemGroup6;
        private System.Windows.Forms.RibbonButton ribbonButton23;
        private System.Windows.Forms.RibbonButton ribbonButton24;
        private System.Windows.Forms.RibbonButton ribbonButton25;
        private System.Windows.Forms.RibbonItemGroup ribbonItemGroup7;
        private System.Windows.Forms.RibbonItemGroup ribbonItemGroup8;
        private System.Windows.Forms.RibbonItemGroup ribbonItemGroup9;
        private System.Windows.Forms.RibbonItemGroup ribbonItemGroup10;
        private System.Windows.Forms.RibbonItemGroup ribbonItemGroup11;
        private System.Windows.Forms.RibbonButton ribbonButton26;
        private System.Windows.Forms.RibbonButton ribbonButton27;
        private System.Windows.Forms.RibbonButton ribbonButton28;
        private System.Windows.Forms.RibbonButton ribbonButton29;
        private System.Windows.Forms.RibbonButton ribbonButton30;
        private System.Windows.Forms.RibbonColorChooser ribbonColorChooser3;
        private System.Windows.Forms.RibbonButton ribbonButton31;
        private System.Windows.Forms.RibbonItemGroup ribbonItemGroup12;
        private System.Windows.Forms.RibbonButton ribbonButton32;
        private System.Windows.Forms.RibbonButton ribbonButton33;
        private System.Windows.Forms.RibbonButton ribbonButton34;
        private System.Windows.Forms.RibbonButton ribbonButton35;
        private System.Windows.Forms.RibbonPanel ribbonPanel4;
        private System.Windows.Forms.RibbonButtonList lst;
        private System.Windows.Forms.RibbonButton ribbonButton36;
        private System.Windows.Forms.RibbonButton ribbonButton37;
        private System.Windows.Forms.RibbonButton itemColors;
        private System.Windows.Forms.RibbonButton ribbonButton39;
        private System.Windows.Forms.RibbonSeparator ribbonSeparator1;
        private System.Windows.Forms.RibbonButton ribbonButton40;
        private System.Windows.Forms.RibbonButton ribbonButton38;
        private System.Windows.Forms.RibbonSeparator ribbonSeparator2;
        private System.Windows.Forms.RibbonButton ribbonButton41;
        private System.Windows.Forms.RibbonButton ribbonButton42;
        private System.Windows.Forms.RibbonButton ribbonButton43;
        private System.Windows.Forms.RibbonButton ribbonButton44;
        private System.Windows.Forms.RibbonButton ribbonButton45;
        private System.Windows.Forms.RibbonOrbMenuItem ribbonOrbMenuItem1;
        private System.Windows.Forms.RibbonOrbMenuItem ribbonOrbMenuItem2;
        private System.Windows.Forms.RibbonOrbMenuItem ribbonOrbMenuItem3;
        private System.Windows.Forms.RibbonOrbMenuItem ribbonOrbMenuItem4;
        private System.Windows.Forms.RibbonSeparator ribbonSeparator3;
        private System.Windows.Forms.RibbonOrbMenuItem ribbonOrbMenuItem5;
        private System.Windows.Forms.RibbonOrbMenuItem ribbonOrbMenuItem6;
        private System.Windows.Forms.RibbonOrbMenuItem ribbonOrbMenuItem7;
        private System.Windows.Forms.RibbonOrbMenuItem ribbonOrbMenuItem8;
        private System.Windows.Forms.RibbonSeparator ribbonSeparator4;
        private System.Windows.Forms.RibbonOrbMenuItem ribbonOrbMenuItem9;
        private System.Windows.Forms.RibbonDescriptionMenuItem ribbonDescriptionMenuItem1;
        private System.Windows.Forms.RibbonDescriptionMenuItem ribbonDescriptionMenuItem2;
        private System.Windows.Forms.RibbonDescriptionMenuItem ribbonDescriptionMenuItem3;
        private System.Windows.Forms.RibbonDescriptionMenuItem ribbonDescriptionMenuItem4;
        private System.Windows.Forms.RibbonDescriptionMenuItem ribbonDescriptionMenuItem5;
        private System.Windows.Forms.RibbonSeparator ribbonSeparator5;
        private System.Windows.Forms.RibbonDescriptionMenuItem ribbonDescriptionMenuItem6;
        private System.Windows.Forms.RibbonDescriptionMenuItem ribbonDescriptionMenuItem7;
        private System.Windows.Forms.RibbonDescriptionMenuItem ribbonDescriptionMenuItem8;
        private System.Windows.Forms.RibbonSeparator ribbonSeparator6;
        private System.Windows.Forms.RibbonOrbOptionButton ribbonOrbOptionButton1;
        private System.Windows.Forms.RibbonOrbOptionButton ribbonOrbOptionButton2;
        private System.Windows.Forms.RibbonOrbRecentItem ribbonOrbRecentItem1;
        private System.Windows.Forms.RibbonOrbRecentItem ribbonOrbRecentItem2;
        private System.Windows.Forms.RibbonOrbRecentItem ribbonOrbRecentItem3;
        private System.Windows.Forms.RibbonPanel ribbonPanel5;
        private System.Windows.Forms.RibbonButton ribbonButton46;
        private System.Windows.Forms.RibbonButton ribbonButton47;
        private System.Windows.Forms.RibbonButton ribbonButton48;
        private System.Windows.Forms.RibbonButton ribbonButton49;
        private System.Windows.Forms.RibbonButton ribbonButton50;
        private System.Windows.Forms.RibbonButton ribbonButton51;
        private System.Windows.Forms.RibbonButton ribbonButton52;
    }
}