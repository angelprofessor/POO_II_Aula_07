using System;
using System.Collections.Generic;
using System.Text;

namespace System.Windows.Forms
{
    public class RibbonToolTip
        : RibbonPopup
    {
        #region Fields

        #endregion

        #region Ctor

        public RibbonToolTip()
        {

        }

        #endregion

        #region Props



        #endregion

        #region Methods

        #endregion

        #region Overrides
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);


        } 
        #endregion
    }
}
