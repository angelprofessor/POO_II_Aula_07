﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UNIP.POOII.DB_BlibliotecaPOOII
{
    public class tbLivrosAutores : dbTabelas, IDBBanco
    {
        public bool Salvar()
        {
            throw new NotImplementedException();
        }

        public bool Atualizar()
        {
            throw new NotImplementedException();
        }

        public bool Apagar()
        {
            throw new NotImplementedException();
        }

        public bool Consultar()
        {
            throw new NotImplementedException();
        }
    }
}
